# importation de tkinter
from tkinter import *
# askopenfilename nous permet de parcourir les fichiers de l'ordinateur pour choisir l'image de la personne
from tkinter.filedialog import askopenfilename
# showerror permet d'afficher une fenetre d'erreur
# showinfo permet d'afficher une fenetre d'information
from tkinter.messagebox import showerror, showinfo
#from listedesutilisateurs import listeUtilisateurs


fen = Tk()
fen.geometry("300x320+300+150")
fen.title("Page de Connexion")

contenu = Canvas(fen,bg="#FF7800")

fontLabel = 'arial 13 bold'
fontEntre = 'arial 11 old'

prenom = Label(contenu, text="Votre prenom :", font = fontLabel, fg='white', bg="#FF7800")
nom = Label(contenu, text="Votre nom :", font = fontLabel, fg='white', bg="#FF7800")
telephone = Label(contenu, text="Votre numéro de téléphone :", font = fontLabel, fg='white', bg="#FF7800")
email = Label(contenu, text="Votre email :", font = fontLabel, fg='white', bg="#FF7800")
login = Label(contenu, text="Votre login :", font = fontLabel, fg='white', bg="#FF7800")
pwd = Label(contenu, text="Votre mot de passe :", font = fontLabel, fg='white', bg="#FF7800")
Validation = Label(contenu, text="Renseigner vos informations ici :", font = fontLabel, fg='#FF7800', bg="white")
photo = Label(contenu, text="Votre photo :", font = fontLabel, fg='white', bg="#FF7800")

prenomEntre = Entry(contenu, font=fontEntre)
nomEntre = Entry(contenu, font=fontEntre)
telephoneEntre = Entry(contenu, font=fontEntre)
emailEntre = Entry(contenu,fontEntre)
loginEntre = Entry(contenu,font=fontEntre)
pwd = Entry(contenu,font=fontEntre)
photoEntre = photo = Label(contenu, text="Aucune image sélectionnée :", font = 'arial 8 bold', fg='white', bg="#FF7800")
ButtonParcourir = Button(contenu, text='Pr', command=parcourir, fg="#FF7800", bg='white')

#columspan permet de faire la fusion entre des colonnes
# sticky c'est l'orientation, E pour désigner Est (coté droite)
Validation.grid(row=0,column=0,columnspan=2)
prenom.grid(row=1,column=0,sticky=E,padx=5,pady=5)
nom.grid(row=1,column=0,sticky=E,padx=5,pady=5)
telephone.grid(row=1,column=0,sticky=E,padx=5,pady=5)
email.grid(row=1,column=0,sticky=E,padx=5,pady=5)
login.grid(row=1,column=0,sticky=E,padx=5,pady=5)
pwd.grid(row=1,column=0,sticky=E,padx=5,pady=5)
photo.grid(row=3,column=0,sticky=E,padx=5,pady=5) 

prenomEntre.grid(row=1,column=1,padx=5,pady=5)
nomEntre.grid(row=2,column=1,padx=5,pady=5)
telephoneEntre.grid(row=3,column=1,padx=5,pady=5)
emailEntre.grid(row=4,column=1,padx=5,pady=5)
loginEntre.grid(row=5,column=1,padx=5,pady=5)
photoEntre.grid(row=7,column=0,sticky=W,padx=5,pady=5)
ButtonParcourir.grid(row=3,column=1,sticky=E,padx=5,pady=5)

b1 = Button(fen, text="Valider", command= valider, fg='#FF7800', bg="white")
b2 = Button(fen, text="Reinitialiser", command=Reinitialiser, width=10, fg='#FF7800', bg="white")
b3 = b2 = Button(fen, text="Liste des Utilisateurs", command="", width=10, fg='#FF7800', bg="white")

b1.grid(row=4,column=0,pady=5)
b2.grid(row=5,column=0,pady=5)
b3.grid(row=6,column=0,pady=5)

contenu.grid(row=0,column=0,padx=5,pady=5)

fen.mainloop()