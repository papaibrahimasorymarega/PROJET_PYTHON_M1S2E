from tkinter import *
from tkinter import messagebox
from PIL import ImageTk
import pymysql

# fonction qui permet de cacher le mot de passe avec l'image de l'oeil
# Chaque fois q'on clique sur l'oeil, l'autre fonction est appelée et vice-versa
def hide():
    open_eye.config(file='closeye.png')
    passwordEntry.config(show='*')
    eyeButton.config(command=show)

# fonction qui permet d'afficher le mot de passe en clair
def show():
    open_eye.config(file='openeye.png')
    passwordEntry.config(show='')
    eyeButton.config(command=hide)



#permet de supprimer les données sur la page une fois qu'elles ont été stoquées sur la BD
def clear():
    nameEntry.delete(0,END)
    telephoneEntry.delete(0,END)
    emailEntry.delete(0,END)
    loginEntry.delete(0,END)
    passwordEntry.delete(0,END)
    #remettre la variable chekh à 0, pour enlever ce qui avait été coché au niveau des conditions d'utilisation
    check.set(0)

#permet de gerer la base de données
#lorsqu'il ya un champ manquant, il sera affiché un message d'erreur dans une boite de dialogue
#pareil lorsque les conditions d'utilisation ne sont pas acceptées
#si les infos sont tous renseignées, ils seront stoquées dans la base de données
#le premier try-except gère la connection à la base de données
#en affichant un message d'erreur si la connection à la BD a échouée
def connect_database():
    if nameEntry.get() == '' or telephoneEntry.get() == '' or emailEntry.get() == '' or loginEntry.get() == '' or passwordEntry.get() == '':
        messagebox.showerror('Erreur', 'tous les champs sont obligatoires')
    elif check.get() == 0:
        messagebox.showerror('Erreur', 'Veuillez accepter les conditions d\'utilisation')
    else:
        try:
            con = pymysql.connect(host='localhost',user='root', password='')
            mycursor = con.cursor()
        except:
            messagebox.showerror('Erreur', 'Echec de la connection à la base de données, essayer à nouveau')
            return
        #Ce 2eme try-exception gère les messages d'erreur liés à la recréation de la base de données
        try:
            query = 'create database projetexamen'
            mycursor.execute(query)
            query='use projetexamen'
            mycursor.execute(query)
            query='create table userdata(id int auto_increment primary key not null, prenomETnom varchar(50), telephone varchar(20), email varchar(50), login varchar(50), password varchar(20) )'
            mycursor.execute(query)
        except:
            mycursor.execute('use projetexamen')
            
        #requete permettant de vérifier si l'utilisateur existe
        query = 'select * from userdata where login=%s'
        mycursor.execute(query,(loginEntry.get()))

        #recherche d'une ligne sur le resultat de la requete précédente
        row = mycursor.fetchone()
        if row != None:
            messagebox.showerror('Erreur', 'Ce login existe déjà')
        else:
            #requete sql permettant d'inserer ce que l'utilisateur a saisi, sur la base de données
            query = 'insert into userdata(prenomETnom,telephone,email,login,password) values(%s,%s,%s,%s,%s)'
            mycursor.execute(query,(nameEntry.get(),telephoneEntry.get(),emailEntry.get(),loginEntry.get(),passwordEntry.get()))
            #permet de valider la modification des données
            con.commit()
            #permet de se deconnecter de la base de données
            con.close()
            messagebox.showinfo('Succès','votre compte a été créé avec succès')
            clear()
            #permet de fermer la fenetre de creation de compte
            fenetre_creation_compte.destroy()
            #affiche la fenetre de connexion
            import connexion

# permet de se rediriger vers la page de connexion
def login_page():
    fenetre_creation_compte.destroy()
    import connexion




fenetre_creation_compte = Tk()
fenetre_creation_compte.title('Page de creation de compte')
fenetre_creation_compte.resizable(False,False)

#Ajout d'une image en tant que background
background = ImageTk.PhotoImage(file='bg.jpg')
bgLabel = Label(fenetre_creation_compte,image=background)
bgLabel.grid()

#Creation d'un cadre
frame = Frame(fenetre_creation_compte, bg='white')
frame.place(x=554,y=100)

#Creation de l'entete
entete = Label(frame,text='Creer Un Compte', font=('Microsoft yahei UI Light',18,'bold')
               ,bg='white',fg='firebrick1')
entete.grid(row=0,column=0,padx=40,pady=10)

#Creation du label PRENOM ET NOM
#sticky permet de faire une orientation du champ
# prend deux valeurs E (Est ou coté droite) ou W (Ouest ou coté gauche)
nameLabel = Label(frame, text="Prenom & Nom", font=('Microsoft yahei UI Light',10,'bold') ,bg='white'
                   ,fg='firebrick1') 
nameLabel.grid(row=1,column=0,sticky='w',padx=25,pady=(10,0))
#permet de créer un champ de saisie
nameEntry = Entry(frame,width=25, font=('Microsoft yahei UI Light',10,'bold'),
                   fg='white', bg='firebrick1')
nameEntry.grid(row=2, column=0, sticky='w',padx=25)


#Creation du label TELEPHONE
telephoneLabel = Label(frame, text="telephone", font=('Microsoft yahei UI Light',10,'bold') ,bg='white'
                   ,fg='firebrick1') 
telephoneLabel.grid(row=3,column=0,sticky='w',padx=25,pady=(10,0))
#permet de créer un champ de saisie
telephoneEntry = Entry(frame,width=25, font=('Microsoft yahei UI Light',10,'bold'),
                   fg='white', bg='firebrick1')
telephoneEntry.grid(row=4, column=0, sticky='w',padx=25)


#Creation du label Email
emailLabel = Label(frame, text="email", font=('Microsoft yahei UI Light',10,'bold') ,bg='white'
                   ,fg='firebrick1') 
emailLabel.grid(row=5,column=0,sticky='w',padx=25,pady=(10,0))
#permet de créer un champ de saisie
emailEntry = Entry(frame,width=25, font=('Microsoft yahei UI Light',10,'bold'),
                   fg='white', bg='firebrick1')
emailEntry.grid(row=6, column=0, sticky='w',padx=25)


#Creation du label LOGIN
loginLabel = Label(frame, text="login", font=('Microsoft yahei UI Light',10,'bold') ,bg='white'
                   ,fg='firebrick1') 
loginLabel.grid(row=7,column=0,sticky='w',padx=25,pady=(10,0))
#permet de créer un champ de saisie
loginEntry = Entry(frame,width=25, font=('Microsoft yahei UI Light',10,'bold'),
                   fg='white', bg='firebrick1')
loginEntry.grid(row=8, column=0, sticky='w',padx=25)


#Creation du label PASSWORD
passwordLabel = Label(frame, text="Mot de Passe", font=('Microsoft yahei UI Light',10,'bold') ,bg='white'
                   ,fg='firebrick1') 
passwordLabel.grid(row=9,column=0,sticky='w',padx=25,pady=(10,0))
#permet de créer un champ de saisie
passwordEntry = Entry(frame,width=25, font=('Microsoft yahei UI Light',10,'bold'),
                   fg='white', bg='firebrick1')
passwordEntry.grid(row=10, column=0, sticky='w',padx=25)


# permet de cacher le mot de passe ou de le voir en clair
# grace à une image sous forme d'un oeil
open_eye = PhotoImage(file='openeye.png')
# bd=0 permet d'enlever la bordure
# activebackgroung='white' permet de mettre à blanc l'arrière plan après le clic du bouton
eyeButton = Button(fenetre_creation_compte,image=open_eye, bd=0, bg='white', activebackground='white'
                   , cursor='hand2', command=hide)
eyeButton.place(x=780,y=422)


check=IntVar()
#Conditions d'ultilisation
Conditions_utilisation = Checkbutton(frame, text="I agree to the Terms & Conditions", cursor='hand2', bg='white',
                                     font=('Microsoft yahei UI Light',10,'bold'), activebackground='white',
                                     fg='firebrick1',  activeforeground='firebrick1', variable=check)
Conditions_utilisation.grid(row=11, column=0, pady=10, padx=15)


#Bouton de validation de l'inscription
bouton_inscription = Button(frame, text='S\'inscrire',font=('Open Sans',10,'bold'),bd=0,
                            bg='firebrick1', fg='white', activebackground='white', 
                            activeforeground='firebrick1', width=17, command=connect_database)
bouton_inscription.grid(row=12, column=0,pady=10)


#question pour savoir si l'utilisateur possède un compte
compte_existant = Label(frame, text='Vous n\'avez pas de compte?',font=('Open Sans',9,'bold'),
                            bg='white', fg='firebrick1')
compte_existant.grid(row=13,column=0, sticky='w', padx=5) 

#redirection vers la page de connexion
signin_button = Button(frame, text='Se connecter', font=('Open Sans',9,'bold underline')
                       , bg='white', fg='blue', bd=0, cursor='hand2', activebackground='white',
                        activeforeground='blue', command=login_page)
signin_button.place(x=180,y=440)


fenetre_creation_compte.mainloop()