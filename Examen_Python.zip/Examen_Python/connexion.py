from tkinter import *
# pour ajouter une image jpg dans notre fenetre (background)
from PIL import ImageTk
# instanciation d'un objet TK pour accéder aux méthodes de tkinter

# permet de se rediriger vers la page de création de compte
def page_creation_compte():
    page_connexion.destroy()
    import creation_compte

# fonction qui permet de cacher le mot de passe avec l'image de l'oeil
# Chaque fois q'on clique sur l'oeil, l'autre fonction est appelée et vice-versa
def hide():
    open_eye.config(file='closeye.png')
    passwordEntre.config(show='*')
    eyeButton.config(command=show)

# fonction qui permet d'afficher le mot de passe en clair
def show():
    open_eye.config(file='openeye.png')
    passwordEntre.config(show='')
    eyeButton.config(command=hide)

# fonction qui permet de supprimer le texte pré rempli (Identifiant), après un click
def saisi_login(event):
    if loginEntre.get() == 'login':
        loginEntre.delete(0,END)

# fonction qui permet de supprimer le texte pré rempli (Mot de passe), après un click
def saisi_password(event):
    if passwordEntre.get() == 'Mot de Passe':
        passwordEntre.delete(0,END)

# Instenciation d'un objet tkinter
page_connexion = Tk()
# permet de redimensioner la fenetre
page_connexion.geometry('990x660+50+50')
#permet de rendre fixe la fenetre, de ne pas avoir la possibilité d'agrandir la fenetre, ni de la diminuer
page_connexion.resizable(0,0)
#permet de donner un titre à la fenetre
page_connexion.title('page de connexion')

#Ajout d'une image en tant que arrière plan
bgImage = ImageTk.PhotoImage(file='bg.jpg')
bgLabel = Label(page_connexion,image=bgImage)
#permet de placer l'image sur la fenetre aux positions indiquées
bgLabel.place(x=0,y=0)

#Creation de l'entete
entete = Label(page_connexion,text='Connection Users', font=('Microsoft yahei UI Light',23,'bold')
               ,bg='white',fg='firebrick1')
entete.place(x=570, y=120)

#Creation du champ Login
loginEntre = Entry(page_connexion,width=25,font=('Microsoft yahei UI Light',11,'bold')
                   ,bd=0,fg='firebrick1')
loginEntre.place(x=580,y=200)
loginEntre.insert(0,'login')
loginEntre.bind('<FocusIn>', saisi_login)
#Création d'un cadre (une ligne horizontale)
frame1 = Frame(page_connexion, width=250, height=2, bg='firebrick1')
frame1.place(x=580, y=222)

#Creation du champ password
passwordEntre = Entry(page_connexion,width=25,font=('Microsoft yahei UI Light',11,'bold')
                   ,bd=0,fg='firebrick1')
passwordEntre.place(x=580,y=260)
passwordEntre.insert(0,'Mot de Passe')
passwordEntre.bind('<FocusIn>', saisi_password)
#Création d'un cadre (une ligne horizontale)
frame2 = Frame(page_connexion, width=250, height=2, bg='firebrick1')
frame2.place(x=580, y=282)

# permet de cacher le mot de passe ou de le voir en clair
# grace à une image sous forme d'un oeil
open_eye = PhotoImage(file='openeye.png')
# bd=0 permet d'enlever la bordure
# activebackgroung='white' permet de mettre à blanc l'arrière plan après le clic du bouton
eyeButton = Button(page_connexion,image=open_eye, bd=0, bg='white', activebackground='white'
                   , cursor='hand2', command=hide)
eyeButton.place(x=800,y=255)

#Bouton qui redirige vers la page de récupération de compte
forgetButton = Button(page_connexion, text='Mot de Passe Oublié ?', bd=0, bg='white', activebackground='white'
                   , cursor='hand2', font=('Microsoft yahei UI Light',9,'bold')
                   , fg='firebrick1' , activeforeground='firebrick1')
forgetButton.place(x=680,y=295)

# Boutton se connecter
loginButton = Button(page_connexion, text='Se connecter', font=('Microsoft yahei UI Light',9,'bold'),
                    fg='white', bg='firebrick1', activebackground='firebrick1'
                    , activeforeground='white', cursor='hand2', bd=0, width=30)
loginButton.place(x=578,y=350)

#Séparateur
or_label = Label(page_connexion, text='------------------ OR ------------------', font=('Open Sans',16)
                , fg='firebrick1', bg='white')
or_label.place(x=550,y=400)

#Ajout du logo facebook
facebook_logo = PhotoImage(file='facebook.png')
fb_label = Label(page_connexion, image=facebook_logo, bg='white')
fb_label.place(x=640,y=440)

#Ajout du logo google
google_logo = PhotoImage(file='google.png')
google_label = Label(page_connexion, image=google_logo, bg='white')
google_label.place(x=690,y=440)

#Ajout du logo twitter
twitter_logo = PhotoImage(file='twitter.png')
twitter_label = Label(page_connexion, image=twitter_logo, bg='white')
twitter_label.place(x=740,y=440)

#Creation du bouton se connecter pour la vérification de l'authentification
sign_up_label = Label(page_connexion, text='Vous n\'avez pas de compte?', font=('Open Sans',9,'bold')
                , fg='firebrick1', bg='white')
sign_up_label.place(x=570,y=500)

#Cretaion de nouvel compte
new_account_Button = Button(page_connexion, text='Inscrivez-vous!', font=('Open Sans',9,'bold underline'),
                    fg='blue', bg='white', activebackground='white'
                    , activeforeground='blue', cursor='hand2', bd=0, command=page_creation_compte)
new_account_Button.place(x=740,y=500)

#Affiche la fenetre et reste à l'écoute d'une action pour faire executer le programme
page_connexion.mainloop()


